package com.project.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"features"},
		glue = {"com.project.stepdefinition"}
		//tags = {"@execute"}
		)
public class ProjectTesting {

}

/*Scenario: User Wants to register to Capbook
Given: User is trying to Register on Capbook on the browser

When: User signup without entering 'personFirstName'
Then: 'User First Name Should Not Be Empty' alert message should be displayed

When: User signup without entering 'personLastName'
Then: 'User Last Name Should Not Be Empty' alert message should be displayed

When: User signup without entering 'dateOfBirthOfPerson'
Then: 'Date of Birth Should Not Be Empty' alert message should be displayed

When: User signup without entering 'personEmailId'
Then: 'Email Id Should Not Be Empty or Invalid' alert message should be displayed

When: User signup without entering 'securityAnswer'
Then: 'Security Answer is required for password recovery' alert message should be displayed

When: User signup without entering 'personPassword'
Then: 'Password Should Not Be Empty and Should contain at least One Capital letter, One special character and One Number' alert message should be displayed

When: User signup without entering 'repeatPersonPassword'
Then: 'Confirm Password Should Not Be Empty' alert message should be displayed*/